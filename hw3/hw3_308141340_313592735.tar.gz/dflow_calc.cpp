/* 046267 Computer Architecture - HW #3 */
/* Implementation (skeleton)  for the dataflow statistics calculator */

#include "dflow_calc.h"
#include <iostream>
#include <vector>

using namespace std;

class Node {
	public:
	
	//unsigned int opcode;
	//int dstIdx;
	//unsigned int src1Idx;
	//unsigned int src2Idx;
	uint32_t opTime;
	unsigned int idx;
	uint32_t branchTime = 0;
	uint32_t branchTimeNoExe = 0;
	Node* dst1;
	Node* dst2;
	Node(unsigned int _idx, InstInfo ins, uint32_t _opTime) {
		//opcode = ins.opcode;
		//dstIdx = ins.dstIdx;
		//src1Idx = ins.src1Idx;
		idx = _idx;
		opTime = _opTime;
		dst1 = nullptr;
		dst2 = nullptr;
	}
	~Node() {};
};


class Graph {
		public:
		uint32_t numVertices; // Number of vertices in the graph
		vector<Node*> adjList; // Adjacency list
		static uint32_t maxTime;
		Graph(int numOfInsts) : numVertices(numOfInsts) {
			//adjList.resize(numVertices);
			//addEdge(nullptr); //Entry Node
		}

		// Function to add an edge between two nodes
		void addEdge(Node* dest) {
			if (dest == nullptr) return;
			adjList.push_back(dest);
			//adjList[i] = dest;
		}
		
		uint32_t MaxTime(unsigned int idx) {
			if (adjList[idx]->dst1 != nullptr && adjList[idx]->dst2 != nullptr) return max(adjList[idx]->dst1->branchTime, adjList[idx]->dst2->branchTime);
			else if (adjList[idx]->dst1 == nullptr && adjList[idx]->dst2 == nullptr) return 0;
			else if (adjList[idx]->dst1 == nullptr) return adjList[idx]->dst2->branchTime;
			else return adjList[idx]->dst1->branchTime;

		}
		~Graph() {};
};

Graph graph(0);
uint32_t Graph::maxTime=0;

ProgCtx analyzeProg(const unsigned int opsLatency[], const InstInfo progTrace[], uint32_t numOfInsts) {
	//Graph graph(numOfInsts);
	graph.numVertices = numOfInsts;
	unsigned int i, j;
    for (i = 0; i < numOfInsts; i++) {
        Node* node = new Node(i, progTrace[i], opsLatency[progTrace[i].opcode]);
        graph.addEdge(node);
    }
	
	for (i = 0; i < numOfInsts; i++) {
		for (j = i+1; j < numOfInsts; j++) {
			if ((unsigned)progTrace[i].dstIdx == progTrace[j].src1Idx) {
				graph.adjList[j]->dst1 = graph.adjList[i]; // Pointer to dependencies
			}
			if ((unsigned)progTrace[i].dstIdx == progTrace[j].src2Idx) {
				graph.adjList[j]->dst2 = graph.adjList[i]; // Pointer to dependencies
			}
		}
		graph.adjList[i]->branchTime = graph.MaxTime(i) + graph.adjList[i]->opTime;
		graph.maxTime = (graph.adjList[i]->branchTime > graph.maxTime) ? graph.adjList[i]->branchTime : graph.maxTime;
		graph.adjList[i]->branchTimeNoExe = graph.adjList[i]->branchTime - graph.adjList[i]->opTime;
		//cout << "op " << i << ", branch time: " << graph.adjList[i]->branchTime << ", max time entry to exit: " << graph.maxTime << ", branch time w/o exe: " << graph.adjList[i]->branchTimeNoExe << endl;
	}	
    return graph.adjList[0];
}

void freeProgCtx(ProgCtx ctx) {
    for (Node* node : graph.adjList) {
        delete node;
    }
    
    //delete graph;
}

int getInstDepth(ProgCtx ctx, unsigned int theInst) {
	if (theInst >= graph.numVertices || theInst < 0) {
		return -1;
	}

	return graph.adjList[theInst]->branchTimeNoExe;
	
}

int getInstDeps(ProgCtx ctx, unsigned int theInst, int *src1DepInst, int *src2DepInst) {
	if (theInst >= graph.numVertices || theInst < 0) {
		return -1; //invalid
	}
	*src1DepInst = (graph.adjList[theInst]->dst1 == nullptr) ? -1 : graph.adjList[theInst]->dst1->idx;
	*src2DepInst = (graph.adjList[theInst]->dst2 == nullptr) ? -1 : graph.adjList[theInst]->dst2->idx;

	return 0;
}

int getProgDepth(ProgCtx ctx) {
	return graph.maxTime;
    //return 0;
}


